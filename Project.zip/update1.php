<html>
<head>
<title>update records</title>
<style>
  table,tr,th{
    text-align:center;
    border-spacing:initial;
    padding:5px;
  }
  th{
    font-size:19px;
    color:violet;
  }
  </style>
</head>
<body>
<?php
     $conn = mysqli_connect('localhost','root','');
     mysqli_select_db($conn,'project');
     $sql = "SELECT * FROM student";
     $result = mysqli_query($conn,$sql);
 ?>
<table>
    <tr>
        <th>Usn &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>FName &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>LName &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Dob &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Branch &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Age &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
		    <th>Email &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
	    	<th>Aggrt</th>
	  </tr>
</table>    
<?php
  while($row = mysqli_fetch_array($result))
  {
    echo "<tr><form action=update_student.php method=post>";
    echo "<td><input type=text name=usn value='".$row['usn']."'</td>";
    echo "<td><input type=text name=fname value='".$row['fname']."'</td>";
    echo "<td><input type=text name=lname value='".$row['lname']."'</td>";
    echo "<td><input type=text name=dob value='".$row['dob']."'</td>";
    echo "<td><input type=text name=branch value='".$row['branch']."'</td>";
    echo "<td><input type=text name=age value='".$row['age']."'</td>";
    echo "<td><input type=text name=email value='".$row['email']."'</td>";
    echo "<td><input type=text name=aggrt value='".$row['aggrt']."'</td>";
    echo "<input type=hidden name=usn value='".$row['usn']."'>";
    echo "<td><input type=submit>";
    echo "</form></tr>";
  }
?> 
<br>
<br>
<br>
<a href="student.html">BACK</a> 
</body>           
</html>