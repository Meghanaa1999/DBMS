<?php
$cid = filter_input(INPUT_POST,'cid');
$cname = filter_input(INPUT_POST,'cname');
$clocation = filter_input(INPUT_POST,'clocation');
$email = filter_input(INPUT_POST,'email');
if(!empty($cid)){
    $conn= mysqli_connect ("localhost","root","","project");
    if(mysqli_connect_error()) {
    die('Connection Failed('.mysqli_connect_error().')'
      .mysqli_connect_error());
} 
else{
    $sql = "INSERT INTO company(cid,cname,clocation,email)VALUES('$cid','$cname','$clocation','$email')"; 
    if($conn->query($sql)===TRUE)
    {
        $message = 'Record inserted successfully!!';
        echo "<SCRIPT type='text/javascript'> 
            alert('$message');
            window.location.replace('insert_company.html');
        </SCRIPT>";
    }
    else{
        echo "Error".$sql.$conn->error;
    }
    $conn->close();
}  
}
else{
    echo "CID should not be empty";
    die();
}
?>