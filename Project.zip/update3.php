<html>
<head>
    <title>update records</title>
</head>
<style>
  table,tr,th{
    text-align:center;
    border-spacing:inherit;
  }
  th{
    font-size:19px;
    color:violet;
  }
</style>
<body>
<?php
     $conn = mysqli_connect('localhost','root','');
     mysqli_select_db($conn,'project');
     $sql = "SELECT * FROM criteria";
     $result = mysqli_query($conn,$sql);
 ?>
<table>
    <tr>
        <th>Crno  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Stream &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Cgpa  &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Cid </th>
    </tr>
</table>    
<?php
  while($row = mysqli_fetch_array($result))
  {
    echo "<tr><form action=update_criteria.php method=post>";
    echo "<td><input type=text name=crno value='".$row['crno']."'</td>";
    echo "<td><input type=text name=stream value='".$row['stream']."'</td>";
    echo "<td><input type=text name=cgpa value='".$row['cgpa']."'</td>";
    echo "<td><input type=text name=cid value='".$row['cid']."'</td>";
    echo "<input type=hidden name=crno value='".$row['crno']."'>";
    echo "<td><input type=submit>";
    echo "</form></tr>";
  }
?> 
<br>
<br> 
<br>
<a href="criteria.html">BACK</a>  
</body>           
</html>