<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";
$conn= new mysqli ($servername,$username,$password,$dbname);
if($conn->connect_error) {
die("Connection Failed.".$conn->connect_error);
}
$cid=$_POST['cid']; 
mysqli_select_db($conn,$dbname);
$sql = "SELECT cid,cname,clocation,email FROM company WHERE cid='$cid'";
$records=mysqli_query($conn,$sql);
?> 
<!DOCTYPE html>
<html>
<head>
<title>Display</title>
<style>
body{
  background-color:white;
  background-size:100% 100%;
}
</style>
</head>
<body>
  <table width="auto" border="1" cellpadding="7" cellspacing="5" align="center"> 
     <tr>
     <th>Cid</th>
     <th>Cname</th>
     <th>Clocation</th>
     <th>Email</th>
     </tr>
     <?php
     while($disp=mysqli_fetch_assoc($records)) {
       echo "<tr>";
       echo "<td>".$disp['cid']."</td>";
       echo "<td>".$disp['cname']."</td>";
       echo "<td>".$disp['clocation']."</td>";
       echo "<td>".$disp['email']."</td>";
      }
     ?>
  </table>
</body>
</html>