<?php
$conn = mysqli_connect('localhost','root','');
mysqli_select_db($conn,'project');
$sql = "UPDATE phone SET phno='$_POST[phno]', usn='$_POST[usn]' WHERE phno='$_POST[phno]'";
if(mysqli_query($conn,$sql))
{
    $message = 'Record updated successfully!!';
    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace('update8.php');
    </SCRIPT>";
}
else 
    echo "Not updated";
?>