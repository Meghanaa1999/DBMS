<?php
$conn = mysqli_connect('localhost','root','');
mysqli_select_db($conn,'project');
$sql = "UPDATE placed SET usn='$_POST[usn]', pcompany='$_POST[pcompany]' , package='$_POST[package]', pyear='$_POST[pyear]' WHERE usn='$_POST[usn]'";
if(mysqli_query($conn,$sql))
{
    $message = 'Record updated successfully!!';
    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace('update6.php');
    </SCRIPT>";
}
else 
    echo "Not updated";
?>