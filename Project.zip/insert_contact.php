<?php
$phno = filter_input(INPUT_POST,'phno');
$usn = filter_input(INPUT_POST,'usn');
if(!empty($phno)){
    $conn= mysqli_connect ("localhost","root","","project");
    if(mysqli_connect_error()) {
    die('Connection Failed('.mysqli_connect_error().')'
      .mysqli_connect_error());
} 
else{
    $sql = "INSERT INTO phone(phno,usn)VALUES('$phno','$usn')"; 
    if($conn->query($sql)===TRUE)
    {
        $message = 'Record inserted successfully!!';
        echo "<SCRIPT type='text/javascript'> 
            alert('$message');
            window.location.replace('insert_contact.html');
        </SCRIPT>";
    }
    else{
        echo "Error".$sql.$conn->error;
    }
    $conn->close();
}  
}
else{
    echo "Phone should not be empty";
    die();
}
?>