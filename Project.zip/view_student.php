<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";
$conn= new mysqli ($servername,$username,$password,$dbname);
if($conn->connect_error) {
die("Connection Failed.".$conn->connect_error);
}
$usn=$_POST['usn']; 
mysqli_select_db($conn,$dbname);
$sql = "SELECT usn,fname,lname,dob,branch,age,email,aggrt FROM student WHERE usn='$usn'";
$records=mysqli_query($conn,$sql);
?> 
<!DOCTYPE html>
<html>
<head>
<title>Display</title>
<style>
body{
  background-color:white;
  background-size:100% 100%;
}
</style>
</head>
<body>
  <table width="auto" border="1" cellpadding="7" cellspacing="5" align="center"> 
     <tr>
     <th>Usn</th>
     <th>Fname</th>
     <th>Lname</th>
     <th>Dob</th>
     <th>Branch</th>
     <th>Age</th>
     <th>Email</th>
     <th>Aggrt</th>
     </tr>
     <?php
     while($disp=mysqli_fetch_assoc($records)) {
       echo "<tr>";
       echo "<td>".$disp['usn']."</td>";
       echo "<td>".$disp['fname']."</td>";
       echo "<td>".$disp['lname']."</td>";
       echo "<td>".$disp['dob']."</td>";
       echo "<td>".$disp['branch']."</td>";
       echo "<td>".$disp['age']."</td>";
       echo "<td>".$disp['email']."</td>";
       echo "<td>".$disp['aggrt']."</td>";
     }
     ?>
  </table>
</body>
</html>