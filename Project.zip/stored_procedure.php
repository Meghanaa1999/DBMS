<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";
$conn= new mysqli ($servername,$username,$password,$dbname);
if($conn->connect_error) {
die("Connection Failed.".$conn->connect_error);
}
mysqli_select_db($conn,$dbname);
$sql =  "SELECT s.usn, s.fname, s.lname, p.pcompany, p.package, p.pyear FROM student s, placed p where s.usn=p.usn";
$records=mysqli_query($conn,$sql);

?> 
<!DOCTYPE html>
<html>
<head>
<title>Stored Procedure</title>
<style>
body{
  background-color:white;
  background-size:100% 100%;
}
</style>
</head>
<body>
  <table width="auto" border="1" cellpadding="7" cellspacing="5" align="center"> 
     <tr>
     <th>Usn</th> 
     <th>Fname</th>
     <th>Lname</th>
     <th>Company</th>
     <th>Package</th>
     <th>Year</th>
     </tr>
     <?php

     while($disp=mysqli_fetch_assoc($records)) {
       echo "<tr>";
       echo "<td>".$disp['usn']."</td>";
       echo "<td>".$disp['fname']."</td>";
       echo "<td>".$disp['lname']."</td>";
       echo "<td>".$disp['pcompany']."</td>";
       echo "<td>".$disp['package']."</td>";
       echo "<td>".$disp['pyear']."</td>";
     }
     ?>
  </table>
</body>
 
</html>