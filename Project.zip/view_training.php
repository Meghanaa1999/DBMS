<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";
$conn= new mysqli ($servername,$username,$password,$dbname);
if($conn->connect_error) {
die("Connection Failed.".$conn->connect_error);
}
$tid=$_POST['tid']; 
mysqli_select_db($conn,$dbname);
$sql = "SELECT tid,tname,tdate,tlocation,usn FROM training WHERE tid='$tid'";
$records=mysqli_query($conn,$sql);
?> 
<!DOCTYPE html>
<html>
<head>
<title>Display</title>
<style>
body{
  background-color:white;
  background-size:100% 100%;
}
</style>
</head>
<body>
  <table width="auto" border="1" cellpadding="7" cellspacing="5" align="center"> 
     <tr>
     <th>Tid</th>
     <th>Tname</th>
     <th>Tdate</th>
     <th>Tlocation</th>
     <th>Usn</th>
     </tr>
     <?php
     while($disp=mysqli_fetch_assoc($records)) {
       echo "<tr>";
       echo "<td>".$disp['tid']."</td>";
       echo "<td>".$disp['tname']."</td>";
       echo "<td>".$disp['tdate']."</td>";
       echo "<td>".$disp['tlocation']."</td>";
       echo "<td>".$disp['usn']."</td>";
      }
     ?>
  </table>
</body>
</html>