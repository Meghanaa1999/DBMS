<?php
$conn = mysqli_connect('localhost','root','');
mysqli_select_db($conn,'project');
$sql = "UPDATE interview SET cid='$_POST[cid]', idate='$_POST[idate]' , ilocation='$_POST[ilocation]' , round='$_POST[round]'  WHERE cid='$_POST[cid]'";
if(mysqli_query($conn,$sql))
{
    $message = 'Record updated successfully!!';
    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace('update5.php');
    </SCRIPT>";
}
else 
    echo "Not updated";
?>