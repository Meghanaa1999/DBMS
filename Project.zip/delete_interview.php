<?php
$cid = filter_input(INPUT_POST, 'cid');
$conn= mysqli_connect ("localhost","root","","project");
if(mysqli_connect_error()) {
die('Connection Failed('.mysqli_connect_error().')'
  .mysqli_connect_error());
} 
$sql = "DELETE FROM interview WHERE cid='$cid'";
if($conn->query($sql)===TRUE)
{
  $message = 'Record deleted successfully!!';
  echo "<SCRIPT type='text/javascript'> 
      alert('$message');
      window.location.replace('delete_interview.html');
  </SCRIPT>";
}
else
{
    echo "Error deleting record".$sql.$conn->error;
}
$conn->close();
?> 