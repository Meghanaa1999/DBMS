<html>
<head>
<title>update records</title>
<style>
  table,tr,th{
    text-align:center;
    border-spacing:inherit;
  }
  th{
    font-size:19px;
    color:violet;
  }
</style>
</head>
<body>
<?php
     $conn = mysqli_connect('localhost','root','');
     mysqli_select_db($conn,'project');
     $sql = "SELECT * FROM training";
     $result = mysqli_query($conn,$sql);
 ?>
<table>
    <tr>
        <th>Tid &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Tname &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Tdate &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Tlocation &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Usn </th>
    </tr>
</table>    
<?php
  while($row = mysqli_fetch_array($result))
  {
    echo "<tr><form action=update_training.php method=post>";
    echo "<td><input type=text name=tid value='".$row['tid']."'</td>";
    echo "<td><input type=text name=tname value='".$row['tname']."'</td>";
    echo "<td><input type=text name=tdate value='".$row['tdate']."'</td>";
    echo "<td><input type=text name=tlocation value='".$row['tlocation']."'</td>";
    echo "<td><input type=text name=usn value='".$row['usn']."'</td>";
    echo "<input type=hidden name=tid value='".$row['tid']."'>";
    echo "<td><input type=submit>";
    echo "</form></tr>";
  }
?> 
<br>
<br>
<br>
<a href="training.html">BACK</a> 
</body>           
</html>