<?php
$crno = filter_input(INPUT_POST,'crno');
$stream = filter_input(INPUT_POST,'stream');
$cgpa = filter_input(INPUT_POST,'cgpa');
$cid = filter_input(INPUT_POST,'cid');
if(!empty($crno)){
    $conn= mysqli_connect ("localhost","root","","project");
    if(mysqli_connect_error()) {
    die('Connection Failed('.mysqli_connect_error().')'
      .mysqli_connect_error());
} 
else{
    $sql = "INSERT INTO criteria(crno,stream,cgpa,cid)VALUES('$crno','$stream','$cgpa','$cid')"; 
    if($conn->query($sql)===TRUE)
    {
        $message = 'Record inserted successfully!!';
        echo "<SCRIPT type='text/javascript'> 
            alert('$message');
            window.location.replace('insert_criteria.html');
        </SCRIPT>";
    }
    else{
        echo "Error".$sql.$conn->error;
    }
    $conn->close();
}  
}
else{
    echo "Crno should not be empty";
    die();
}
?>