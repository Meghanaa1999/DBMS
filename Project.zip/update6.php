<html>
<head>
<title>update records</title>
<style>
  table,tr,th{
    text-align:center;
    border-spacing:inherit;
  }
  th{
    font-size:19px;
    color:violet;
  }
</style>
</head>
<body>
<?php
     $conn = mysqli_connect('localhost','root','');
     mysqli_select_db($conn,'project');
     $sql = "SELECT * FROM placed";
     $result = mysqli_query($conn,$sql);
 ?>
<table>
    <tr>
        <th>Usn &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Company &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Package &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Year </th>
    </tr>
</table>    
<?php
  while($row = mysqli_fetch_array($result))
  {
    echo "<tr><form action=update_placed.php method=post>";
    echo "<td><input type=text name=usn value='".$row['usn']."'</td>";
    echo "<td><input type=text name=pcompany value='".$row['pcompany']."'</td>";
    echo "<td><input type=text name=package value='".$row['package']."'</td>";
    echo "<td><input type=text name=pyear value='".$row['pyear']."'</td>";
    echo "<input type=hidden name=usn value='".$row['usn']."'>";
    echo "<td><input type=submit>";
    echo "</form></tr>";
  }
?> 
<br>
<br>
<br>
<a href="placed.html">BACK</a> 
</body>           
</html>