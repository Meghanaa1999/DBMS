<?php
$tid = filter_input(INPUT_POST,'tid');
$tname = filter_input(INPUT_POST,'tname');
$tdate = filter_input(INPUT_POST,'tdate');
$tlocation = filter_input(INPUT_POST,'tlocation');
$usn= filter_input(INPUT_POST,'usn');

if(!empty($tid)){
    $conn= mysqli_connect ("localhost","root","","project");
    if(mysqli_connect_error()) {
    die('Connection Failed('.mysqli_connect_error().')'
      .mysqli_connect_error());
} 
else{
    $sql = "INSERT INTO training(tid,tname,tdate,tlocation,usn)VALUES('$tid','$tname','$tdate','$tlocation','$usn')"; 
    if($conn->query($sql)===TRUE)
    {
        $message = 'Record inserted successfully!!';
        echo "<SCRIPT type='text/javascript'> 
            alert('$message');
            window.location.replace('insert_training.html');
        </SCRIPT>";
    }
    else{
        echo "Error".$sql.$conn->error;
    }
    $conn->close();
}  
}
else{
    echo "TID should not be empty";
    die();
}
?>