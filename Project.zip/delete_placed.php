<?php
$usn = filter_input(INPUT_POST, 'usn');
$conn= mysqli_connect ("localhost","root","","project");
if(mysqli_connect_error()) {
die('Connection Failed('.mysqli_connect_error().')'
  .mysqli_connect_error());
} 
$sql = "DELETE FROM placed WHERE usn='$usn'";
if($conn->query($sql)===TRUE)
{
  $message = 'Record deleted successfully!!';
  echo "<SCRIPT type='text/javascript'> 
      alert('$message');
      window.location.replace('delete_placed.html');
  </SCRIPT>";
}
else
{
    echo "Error deleting record".$sql.$conn->error;
}
$conn->close();
?> 