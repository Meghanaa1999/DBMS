<!DOCTYPE>
<html>
<head> 
<title> Display trigger </title>
<style type="text/css">
table{
    width: 100%;
    font-family: monospace;
    font-size: 25px;
    text-align: left;
}
th{
    background-color: violet;
    color: white;
}
</style>
</head>   
<body>
<table>
<tr>
    <th>Usn </th>  
    <th>Company </th>
    <th>Package </th>
</tr>
<?php
    $conn = mysqli_connect("localhost", "root", "", "project");
    if($conn-> connect_error){
        die("Connection Failed". $conn-> connect_error);
    }
    $sql = "SELECT * FROM view2";
    $result = $conn-> query($sql);
    if($result-> num_rows > 0){
    while($row = $result-> fetch_assoc()){
    echo "<tr><td>". $row["usn"] ."</td><td>". $row["pcompany"] ."</td><td>". $row["package"] ."</td><td>";
    }
    echo "</table>";
    }
    else{
        echo "0 result";
    }
    $conn-> close();
?>
</table>
</body>    
</html>    