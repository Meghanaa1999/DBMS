<html>
<head>
    <title>update records</title>
</head>
<style>
  table,tr,th{
    text-align:center;
    border-spacing:inherit;
  }
  th{
    font-size:19px;
    color:violet;
  }
</style>
<body>
<?php
     $conn = mysqli_connect('localhost','root','');
     mysqli_select_db($conn,'project');
     $sql = "SELECT * FROM interview";
     $result = mysqli_query($conn,$sql);
 ?>
<table>
    <tr>
        <th>Cid &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Interview Date &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp </th>
        <th>Location &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp </th>
        <th>Round </th>
	  </tr>
</table>    
<?php
  while($row = mysqli_fetch_array($result))
  {
    echo "<tr><form action=update_interview.php method=post>";
    echo "<td><input type=text name=cid value='".$row['cid']."'</td>";
    echo "<td><input type=text name=idate value='".$row['idate']."'</td>";
    echo "<td><input type=text name=ilocation value='".$row['ilocation']."'</td>";
    echo "<td><input type=text name=round value='".$row['round']."'</td>";
    echo "<input type=hidden name=cid value='".$row['cid']."'>";
    echo "<td><input type=submit>";
    echo "</form></tr>";
  }
?> 
<br>
<br>
<br> 
<a href="interview.html">BACK</a>  
</body>           
</html>