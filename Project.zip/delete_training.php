<?php
$tid = filter_input(INPUT_POST, 'tid');
$conn= mysqli_connect ("localhost","root","","project");
if(mysqli_connect_error()) {
die('Connection Failed('.mysqli_connect_error().')'
  .mysqli_connect_error());
} 
$sql = "DELETE FROM training WHERE tid='$tid'";
if($conn->query($sql)===TRUE)
{
  $message = 'Record deleted successfully!!';
  echo "<SCRIPT type='text/javascript'> 
      alert('$message');
      window.location.replace('delete_training.html');
  </SCRIPT>";
}
else
{
    echo "Error deleting record".$sql.$conn->error;
}
$conn->close();
?> 