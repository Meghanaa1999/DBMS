<?php
$conn = mysqli_connect('localhost','root','');
mysqli_select_db($conn,'project');
$sql = "UPDATE student SET usn='$_POST[usn]', fname='$_POST[fname]' , lname='$_POST[lname]', dob='$_POST[dob]' , branch='$_POST[branch]' , 
       age='$_POST[age]',  email='$_POST[email]', aggrt='$_POST[aggrt]' WHERE usn='$_POST[usn]'";
if(mysqli_query($conn,$sql))
{
    $message = 'Record updated successfully!!';
    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace('update1.php');
    </SCRIPT>";
}
else 
    echo "Not updated";
?>