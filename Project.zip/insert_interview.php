<?php
$cid = filter_input(INPUT_POST,'cid');
$idate = filter_input(INPUT_POST,'idate');
$ilocation = filter_input(INPUT_POST,'ilocation');
$round = filter_input(INPUT_POST,'round');
if(!empty($cid)){
    $conn= mysqli_connect ("localhost","root","","project");
    if(mysqli_connect_error()) {
    die('Connection Failed('.mysqli_connect_error().')'
      .mysqli_connect_error());
} 
else{
    $sql = "INSERT INTO interview(cid,idate,ilocation,round) VALUES('$cid','$idate','$ilocation','$round')"; 
    if($conn->query($sql)===TRUE)
    {
        $message = 'Record inserted successfully!!';
        echo "<SCRIPT type='text/javascript'> 
            alert('$message');
            window.location.replace('insert_interview.html');
        </SCRIPT>";
    }
    else{
        echo "Error".$sql.$conn->error;
    }
    $conn->close();
}  
}
else{
    echo "Cid should not be empty";
    die();
}
?>