<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";
$conn= new mysqli ($servername,$username,$password,$dbname);
if($conn->connect_error) {
die("Connection Failed.".$conn->connect_error);
}
$usn=$_POST['usn']; 
mysqli_select_db($conn,$dbname);
$sql = "SELECT usn,cid FROM applies WHERE usn='$usn'";
$records=mysqli_query($conn,$sql);
?> 
<!DOCTYPE html>
<html>
<head>
<title>Display</title>
<style>
body{
  background-color:white;
  background-size:100% 100%;
}
</style>
</head>
<body>
  <table width="auto" border="1" cellpadding="7" cellspacing="5" align="center"> 
     <tr>
     <th>Usn</th>
     <th>Cid</th>
     </tr>
     <?php
     while($disp=mysqli_fetch_assoc($records)) {
       echo "<tr>";
       echo "<td>".$disp['usn']."</td>";
       echo "<td>".$disp['cid']."</td>";
     }
     ?>
  </table>
</body>
</html>