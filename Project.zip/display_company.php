<!DOCTYPE>
<html>
<head> 
<title> Display company </title>
<style type="text/css">
table{
    width: 100%;
    font-family: monospace;
    font-size: 25px;
    text-align: left;
}
th{
    background-color: violet;
    color: white;
}
</style>
</head>   
<body>
<table>
<tr>
    <th>Cid </th>  
    <th>Cname </th>
    <th>Clocation </th>
    <th>Email </th>
</tr>
<?php
    $conn = mysqli_connect("localhost", "root", "", "project");
    if($conn-> connect_error){
        die("Connection Failed". $conn-> connect_error);
    }
    $sql = "SELECT * FROM company";
    $result = $conn-> query($sql);
    if($result-> num_rows > 0){
    while($row = $result-> fetch_assoc()){
    echo "<tr><td>". $row["cid"] ."</td><td>". $row["cname"] ."</td><td>". $row["clocation"] ."</td><td>".$row["email"] ."</td><td>";
    }
    echo "</table>";
    }
    else{
        echo "0 result";
    }
    $conn-> close();
?>
</table>
</body>    
</html>    