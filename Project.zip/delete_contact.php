<?php
$phno = filter_input(INPUT_POST, 'phno');
$usn = filter_input(INPUT_POST, 'usn');
$conn= mysqli_connect ("localhost","root","","project");
if(mysqli_connect_error()) {
die('Connection Failed('.mysqli_connect_error().')'
  .mysqli_connect_error());
} 
$sql = "DELETE FROM phone WHERE phno='$phno'";
if($conn->query($sql)===TRUE)
{
  $message = 'Record deleted successfully!!';
  echo "<SCRIPT type='text/javascript'> 
      alert('$message');
      window.location.replace('delete_contact.html');
  </SCRIPT>";
}
else
{
    echo "Error deleting record".$sql.$conn->error;
}
$conn->close();
?> 