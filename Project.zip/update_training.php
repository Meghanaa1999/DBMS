<?php
$conn = mysqli_connect('localhost','root','');
mysqli_select_db($conn,'project');
$sql = "UPDATE training SET tid='$_POST[tid]', tname='$_POST[tname]' , tdate='$_POST[tdate]', tlocation='$_POST[tlocation]' , usn='$_POST[usn]'  WHERE tid='$_POST[tid]'";
if(mysqli_query($conn,$sql))
{
    $message = 'Record updated successfully!!';
    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace('update1.php');
    </SCRIPT>";
}
else 
    echo "Not updated";
?>