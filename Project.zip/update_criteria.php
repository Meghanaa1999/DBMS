<?php
$conn = mysqli_connect('localhost','root','');
mysqli_select_db($conn,'project');
$sql = "UPDATE criteria SET crno='$_POST[crno]', stream='$_POST[stream]' , cgpa='$_POST[cgpa]' , cid='$_POST[cid]' WHERE crno='$_POST[crno]'";
if(mysqli_query($conn,$sql))
{
    $message = 'Record updated successfully!!';
    echo "<SCRIPT type='text/javascript'> 
        alert('$message');
        window.location.replace('update3.php');
    </SCRIPT>";
}
else 
    echo "Not updated";
?>