<!DOCTYPE>
<html>
<head> 
<title> Display Operation </title>
<style type="text/css">
table{
    width: 100%;
    font-family: monospace;
    font-size: 25px;
    text-align: left;
}
th{
    background-color: violet;
    color: white;
}
</style>
</head>   
<body>
<table>
<tr>
    <th>Usn </th>  
    <th>Fname </th>
    <th>Lname </th>
    <th>Dob </th>
    <th>Branch </th>
    <th>Age </th>
    <th>Email </th>
    <th>Aggrt </th>
</tr>
<?php
    $conn = mysqli_connect("localhost", "root", "", "project");
    if($conn-> connect_error){
        die("Connection Failed". $conn-> connect_error);
    }
    $sql = "SELECT * FROM student";
    $result = $conn-> query($sql);
    if($result-> num_rows > 0){
    while($row = $result-> fetch_assoc()){
    echo "<tr><td>". $row["usn"] ."</td><td>". $row["fname"] ."</td><td>". $row["lname"] ."</td><td>".$row["dob"] ."</td><td>".$row["branch"] 
         ."</td><td>".$row["age"] ."</td><td>".$row["email"] ."</td><td>". $row["aggrt"] ."</td></tr>";
    }
    echo "</table>";
    }
    else{
        echo "0 result";
    }
    $conn-> close();
?>
</table>
</body>    
</html>    