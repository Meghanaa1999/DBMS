<?php
$usn = filter_input(INPUT_POST,'usn');
$cid = filter_input(INPUT_POST,'cid');
if(!empty($usn)){
    $conn= mysqli_connect ("localhost","root","","project");
    if(mysqli_connect_error()) {
    die('Connection Failed('.mysqli_connect_error().')'
      .mysqli_connect_error());
} 
else{
    $sql = "INSERT INTO applies(usn,cid)VALUES('$usn','$cid')"; 
    if($conn->query($sql)===TRUE)
    {
        $message = 'Record inserted successfully!!';
        echo "<SCRIPT type='text/javascript'> 
            alert('$message');
            window.location.replace('insert_applies.html');
        </SCRIPT>";
    }
    else{
        echo "Error".$sql.$conn->error;
    }
    $conn->close();
}  
}
else{
    echo "USN should not be empty";
    die();
}
?>