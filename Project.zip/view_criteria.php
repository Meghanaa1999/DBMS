<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";
$conn= new mysqli ($servername,$username,$password,$dbname);
if($conn->connect_error) {
die("Connection Failed.".$conn->connect_error);
}
$crno=$_POST['crno']; 
mysqli_select_db($conn,$dbname);
$sql = "SELECT crno,stream,cgpa,cid FROM criteria WHERE crno='$crno'";
$records=mysqli_query($conn,$sql);
?> 
<!DOCTYPE html>
<html>
<head>
<title>Display</title>
<style>
body{
  background-color:white;
  background-size:100% 100%;
}
</style>
</head>
<body>
  <table width="auto" border="1" cellpadding="7" cellspacing="5" align="center"> 
     <tr>
     <th>Crno</th>
     <th>Stream</th>
     <th>Cgpa</th>
     <th>Cid</th>
     </tr>
     <?php
     while($disp=mysqli_fetch_assoc($records)) {
       echo "<tr>";
       echo "<td>".$disp['crno']."</td>";
       echo "<td>".$disp['stream']."</td>";
       echo "<td>".$disp['cgpa']."</td>";
       echo "<td>".$disp['cid']."</td>";
      }
     ?>
  </table>
</body>
</html>