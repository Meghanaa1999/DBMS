<html>
<head>
<title>update records</title>
<style>
  table,tr,th{
    text-align:center;
    border-spacing:inherit;
  }
  th{
    font-size:19px;
    color:violet;
  }
</style>
</head>
<body>
<?php
     $conn = mysqli_connect('localhost','root','');
     mysqli_select_db($conn,'project');
     $sql = "SELECT * FROM applies";
     $result = mysqli_query($conn,$sql);
 ?>
<table>
    <tr>
        <th>Usn &nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp</th>
        <th>Cid </th>
    </tr>
</table>    
<?php
  while($row = mysqli_fetch_array($result))
  {
    echo "<tr><form action=update_applies.php method=post>";
    echo "<td><input type=text name=usn value='".$row['usn']."'</td>";
    echo "<td><input type=text name=cid value='".$row['cid']."'</td>";
    echo "<td><input type=submit>";
    echo "</form></tr>";
  }
?> 
<br>
<br>
<br>
<a href="applies.html">BACK</a> 
</body>           
</html>