<?php
$usn = filter_input(INPUT_POST,'usn');
$fname = filter_input(INPUT_POST,'fname');
$lname = filter_input(INPUT_POST,'lname');
$dob = filter_input(INPUT_POST,'dob');
$branch = filter_input(INPUT_POST,'branch');
$age = filter_input(INPUT_POST,'age');
$email = filter_input(INPUT_POST,'email');
$aggrt= filter_input(INPUT_POST,'aggrt');
if(!empty($usn)){
    $conn= mysqli_connect ("localhost","root","","project");
    if(mysqli_connect_error()) {
    die('Connection Failed('.mysqli_connect_error().')'
      .mysqli_connect_error());
} 
else{
    $sql = "INSERT INTO student(usn,fname,lname,dob,branch,age,email,aggrt)VALUES('$usn','$fname','$lname','$dob','$branch','$age','$email','$aggrt')"; 
    if($conn->query($sql)===TRUE)
    {
        $message = 'Record inserted successfully!!';
        echo "<SCRIPT type='text/javascript'> 
            alert('$message');
            window.location.replace('insert_student.html');
        </SCRIPT>";
    }
    else{
        echo "Error".$sql.$conn->error;
    }
    $conn->close();
}  
}
else{
    echo "Usn should not be empty";
    die();
}
?>