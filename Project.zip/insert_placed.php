<?php
$usn = filter_input(INPUT_POST,'usn');
$pcompany = filter_input(INPUT_POST,'pcompany');
$package = filter_input(INPUT_POST,'package');
$pyear = filter_input(INPUT_POST,'pyear');
if(!empty($usn)){
    $conn= mysqli_connect ("localhost","root","","project");
    if(mysqli_connect_error()) {
    die('Connection Failed('.mysqli_connect_error().')'
      .mysqli_connect_error());
} 
else{
    $sql = "INSERT INTO placed(usn,pcompany,package,pyear)VALUES('$usn','$pcompany','$package','$pyear')"; 
    if($conn->query($sql)===TRUE)
    {
        $message = 'Record inserted successfully!!';
        echo "<SCRIPT type='text/javascript'> 
            alert('$message');
            window.location.replace('insert_placed.html');
        </SCRIPT>";
    }
    else{
        echo "Error".$sql.$conn->error;
    }
    $conn->close();
}  
}
else{
    echo "USN should not be empty";
    die();
}
?>