<?php
$servername="localhost";
$username="root";
$password="";
$dbname="project";
$conn= new mysqli ($servername,$username,$password,$dbname);
if($conn->connect_error) {
die("Connection Failed.".$conn->connect_error);
}
mysqli_select_db($conn,$dbname);
$sql = "SELECT * FROM phone";
$records=mysqli_query($conn,$sql);
?> 
<!DOCTYPE html>
<html>
<head>
<title>Display phone no</title>
<style>
body{
  background-color:white;
  background-size:100% 100%;
}
</style>
</head>
<body>
  <table width="350px" border="1" cellpadding="10" cellspacing="5" align="center"> 
     <tr>
     <th>Phone no</th> 
     <th>Usn</th>
     </tr>
     <?php
     while($disp=mysqli_fetch_assoc($records)) {
       echo "<tr>";
       echo "<td>".$disp['phno']."</td>";
       echo "<td>".$disp['usn']."</td>";
    }
     ?>
  </table>
</body>
 
</html>